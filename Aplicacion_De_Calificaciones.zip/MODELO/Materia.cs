﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace $safeprojectname$
{
    [Table("Materia")]
    public class Materia
    {
        [Key]
        public int IdMateria { get; set; }

        public string Nombre { get; set; }
        public int Creditos { get; set; }
    }
}
