﻿using System.Data.Entity;
using Microsoft.EntityFrameworkCore;
using DbContext = Microsoft.EntityFrameworkCore.DbContext;

namespace $safeprojectname$
{
    public class AppDbContext : DbContext
    {
        public System.Data.Entity.DbSet<Estudiante> Estudiantes { get; set; }
        public System.Data.Entity.DbSet<Profesor> Profesores { get; set; }
        public Microsoft.EntityFrameworkCore.DbSet<Materia> Materias { get; set; }
        public System.Data.Entity.DbSet<Periodo> Periodos { get; set; }
        public System.Data.Entity.DbSet<Inscripcion> Inscripciones { get; set; }
        public System.Data.Entity.DbSet<Calificacion> Calificaciones { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer("Server=LAPTOP-PM56AV40\\SQLEXPRESS;Database=SistemaCalificacionesPro;Trusted_Connection=True;");

        }

    }
}
